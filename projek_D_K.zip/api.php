<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        $data = json_decode(file_get_contents('php://input'), true);
        if (($data['username'] ?? '') === 'admin' && ($data['password'] ?? '') === 'admin123') {
            echo json_encode(["status" => "success", "role" => "admin"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Nesprávné přihlašovací údaje."]);
        }
        break;

    case 'save_matches':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) {
            echo json_encode(["status" => "error", "message" => "Žádná data k uložení."]);
            exit;
        }
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO matches (stage, team1, team2, score1, score2, status) VALUES (?, ?, ?, ?, ?, 'Odehráno')");
            foreach ($data as $m) {
                $stmt->execute([$m['stage'], $m['team1'], $m['team2'], $m['score1'], $m['score2']]);
            }
            $pdo->commit();
            echo json_encode(["status" => "success", "message" => "Zápasy byly bezpečně uloženy do MySQL."]);
        } catch (Exception $e) {
            $pdo->rollBack();
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
        break;

    case 'get_history':
        try {
            $stmt = $pdo->query("SELECT stage, team1, team2, score1, score2, status, DATE_FORMAT(played_at, '%d.%m.%Y %H:%i') as datum FROM matches ORDER BY id DESC");
            $history = $stmt->fetchAll();
            echo json_encode(["status" => "success", "data" => $history]);
        } catch (Exception $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
        break;

    case 'reset_tournament':
        try {
            $pdo->exec("TRUNCATE TABLE teams");
            $pdo->exec("DELETE FROM matches WHERE status = 'Naplánováno'"); 
            echo json_encode(["status" => "success", "message" => "Aktuální turnaj byl resetován. Historie odehraných zápasů byla zachována."]);
        } catch (Exception $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
        break;
        
    case 'hard_reset':
        try {
            $pdo->exec("TRUNCATE TABLE teams");
            $pdo->exec("TRUNCATE TABLE matches");
            echo json_encode(["status" => "success", "message" => "Kompletní databáze byla vyčištěna (včetně historie)."]);
        } catch (Exception $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(["status" => "error", "message" => "Neznámá akce backendu."]);
        break;
}
?>