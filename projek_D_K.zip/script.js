/* script.js - Kompletní, robustní frontendová logika a AJAX komunikace */
document.addEventListener("DOMContentLoaded", () => {
    let appState = {
        teams: [],
        groupMatches: [],
        standings: [],
        playoff: {
            sf1: { t1: "", t2: "", s1: null, s2: null, winner: "" },
            sf2: { t1: "", t2: "", s1: null, s2: null, winner: "" },
            final: { t1: "", t2: "", s1: null, s2: null, winner: "" }
        },
        stage: 0 
    };

    const poolCzechTeams = [
        "AC Sparta Praha", "SK Slavia Praha", "FC Viktoria Plzeň", "FC Baník Ostrava",
        "FC Slovan Liberec", "SK Sigma Olomouc", "FK Mladá Boleslav", "FK Jablonec",
        "Bohemians Praha 1905", "1. FC Slovácko", "FC Hradec Králové", "FK Teplice"
    ];

    checkAuthStatus();
    loadDatabaseHistory();

    function checkAuthStatus() {
        const isLogged = localStorage.getItem("admin_logged") === "true";
        if (isLogged) {
            document.getElementById("login-screen").style.display = "none";
            document.getElementById("app-interface").style.display = "flex";
            restoreLocalState();
        } else {
            document.getElementById("login-screen").style.display = "flex";
            document.getElementById("app-interface").style.display = "none";
        }
    }

    document.getElementById("submitLoginBtn").addEventListener("click", () => {
        const user = document.getElementById("usernameInput").value.trim();
        const pass = document.getElementById("passwordInput").value.trim();

        fetch("api.php?action=login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username: user, password: pass })
        })
        .then(res => res.json())
        .then(res => {
            if (res.status === "success") {
                localStorage.setItem("admin_logged", "true");
                alert("Úspěšně přihlášen jako organizátor turnaje!");
                checkAuthStatus();
            } else {
                alert(res.message);
            }
        })
        .catch(err => alert("Chyba spojení s backendem: " + err));
    });

    document.getElementById("btnAdminLogout").addEventListener("click", () => {
        localStorage.removeItem("admin_logged");
        localStorage.removeItem("tournament_local_state");
        window.location.reload();
    });

    const menuItems = document.querySelectorAll(".menu-item");
    menuItems.forEach(item => {
        item.addEventListener("click", (e) => {
            menuItems.forEach(i => i.classList.remove("active"));
            item.classList.add("active");
            
            const targetTab = item.getAttribute("data-target");
            document.querySelectorAll(".tab-section").forEach(s => s.classList.remove("active"));
            document.getElementById(targetTab).classList.add('active');
            
            updateHeaderTitles(targetTab);
        });
    });

    function updateHeaderTitles(tabId) {
        const titles = {
            "tab-dashboard": { t: "Dashboard & Správa Týmů", d: "Správa zápasů, registrace a losování základních skupin." },
            "tab-group-stage": { t: "Rozpis Zápasů & Tabulka", d: "Zadávání výsledků ze zápasů ve skupině." },
            "tab-bracket-stage": { t: "Play-off Pavouk", d: "Vyřazovací pavouk nejlepších 4 týmů. Semifinále a Finále." },
            "tab-history-stage": { t: "Historie Zápasů z MySQL", d: "Trvalé uložení odehraných turnajů." }
        };
        if(titles[tabId]) {
            document.getElementById("current-tab-title").textContent = titles[tabId].t;
            document.getElementById("current-tab-desc").textContent = titles[tabId].d;
        }
    }

    document.getElementById("btnAddManualTeam").addEventListener("click", () => {
        const input = document.getElementById("manualTeamName");
        const name = input.value.trim();
        if(!name) return;
        if(appState.teams.includes(name)) {
            alert("Tento tým již byl přidán.");
            return;
        }
        appState.teams.push(name);
        input.value = "";
        renderTeamsUI();
        saveLocalState();
    });

    document.getElementById("btnGenerateCzechTeams").addEventListener("click", () => {
        appState.teams = [];
        let shuffled = [...poolCzechTeams].sort(() => 0.5 - Math.random());
        appState.teams = shuffled.slice(0, 4); 
        renderTeamsUI();
        saveLocalState();
    });

    function renderTeamsUI() {
        const list = document.getElementById("registeredTeamsList");
        list.innerHTML = "";
        
        if(appState.teams.length === 0) {
            list.innerHTML = `<div class="empty-state">Žádné týmy nebyly dosud registrovány.</div>`;
            document.getElementById("btnLaunchTournament").disabled = true;
            document.getElementById("teamCountBadge").textContent = "0 Týmů";
            return;
        }

        appState.teams.forEach((team, idx) => {
            const li = document.createElement("li");
            li.innerHTML = `
                <span><b>${idx + 1}.</b> ${team}</span>
                <button class="btn-remove-team" data-index="${idx}">Odebrat</button>
            `;
            list.appendChild(li);
        });

        document.getElementById("teamCountBadge").textContent = `${appState.teams.length} Týmů`;
        document.getElementById("btnLaunchTournament").disabled = (appState.teams.length < 4);

        document.querySelectorAll(".btn-remove-team").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const index = parseInt(btn.getAttribute("data-index"));
                appState.teams.splice(index, 1);
                renderTeamsUI();
                saveLocalState();
            });
        });
    }

    document.getElementById("btnLaunchTournament").addEventListener("click", () => {
        appState.groupMatches = [];
        for(let i = 0; i < appState.teams.length; i++) {
            for(let j = i + 1; j < appState.teams.length; j++) {
                appState.groupMatches.push({
                    team1: appState.teams[i],
                    team2: appState.teams[j],
                    score1: "",
                    score2: ""
                });
            }
        }
        appState.groupMatches.sort(() => 0.5 - Math.random());
        appState.stage = 1;
        
        document.querySelector('[data-target="tab-group-stage"]').click();
        renderGroupMatchesUI();
        calculateGroupTable();
        saveLocalState();
    });

    function renderGroupMatchesUI() {
        const container = document.getElementById("groupMatchesList");
        container.innerHTML = "";

        if(appState.groupMatches.length === 0) {
            container.innerHTML = `<div class="empty-state">Nejprve musíte spustit turnaj na záložce Dashboardu.</div>`;
            return;
        }

        appState.groupMatches.forEach((match, idx) => {
            const div = document.createElement("div");
            div.className = "group-match-row";
            div.innerHTML = `
                <span class="match-team-label text-right">${match.team1}</span>
                <div class="match-inputs-score">
                    <input type="number" min="0" class="input-score-t1" data-index="${idx}" value="${match.score1}">
                    <span>:</span>
                    <input type="number" min="0" class="input-score-t2" data-index="${idx}" value="${match.score2}">
                </div>
                <span class="match-team-label text-left">${match.team2}</span>
            `;
            container.appendChild(div);
        });

        document.querySelectorAll(".input-score-t1").forEach(input => {
            input.addEventListener("input", (e) => {
                const idx = input.getAttribute("data-index");
                appState.groupMatches[idx].score1 = input.value !== "" ? parseInt(input.value) : "";
                calculateGroupTable();
                saveLocalState();
            });
        });

        document.querySelectorAll(".input-score-t2").forEach(input => {
            input.addEventListener("input", (e) => {
                const idx = input.getAttribute("data-index");
                appState.groupMatches[idx].score2 = input.value !== "" ? parseInt(input.value) : "";
                calculateGroupTable();
                saveLocalState();
            });
        });
    }

    function calculateGroupTable() {
        let stats = {};
        appState.teams.forEach(t => {
            stats[t] = { name: t, z: 0, v: 0, r: 0, p: 0, scored: 0, conceded: 0, b: 0 };
        });

        let allMatchesPlayed = true;

        appState.groupMatches.forEach(m => {
            if(m.score1 === "" || m.score2 === "") {
                allMatchesPlayed = false;
                return; 
            }

            stats[m.team1].z++;
            stats[m.team2].z++;
            stats[m.team1].scored += m.score1;
            stats[m.team1].conceded += m.score2;
            stats[m.team2].scored += m.score2;
            stats[m.team2].conceded += m.score1;

            if(m.score1 > m.score2) {
                stats[m.team1].v++; stats[m.team1].b += 3; stats[m.team2].p++;
            } else if(m.score1 < m.score2) {
                stats[m.team2].v++; stats[m.team2].b += 3; stats[m.team1].p++;
            } else {
                stats[m.team1].r++; stats[m.team1].b += 1; stats[m.team2].r++; stats[m.team2].b += 1;
            }
        });

        appState.standings = Object.values(stats).sort((a,b) => {
            if(b.b !== a.b) return b.b - a.b;
            let diffA = a.scored - a.conceded;
            let diffB = b.scored - b.conceded;
            if(diffB !== diffA) return diffB - diffA;
            return b.scored - a.scored;
        });

        const tbody = document.getElementById("groupTableBody");
        tbody.innerHTML = "";

        appState.standings.forEach(row => {
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><strong>${row.name}</strong></td>
                <td>${row.z}</td>
                <td>${row.v}</td>
                <td>${row.r}</td>
                <td>${row.p}</td>
                <td>${row.scored}:${row.conceded}</td>
                <td><span class="table-points-badge">${row.b} b</span></td>
            `;
            tbody.appendChild(tr);
        });

        document.getElementById("btnAdvanceToBracket").disabled = !allMatchesPlayed;
    }

    document.getElementById("btnAdvanceToBracket").addEventListener("click", () => {
        if(appState.standings.length < 4) return;
        
        appState.playoff.sf1.t1 = appState.standings[0].name;
        appState.playoff.sf1.t2 = appState.standings[3].name;
        
        appState.playoff.sf2.t1 = appState.standings[1].name;
        appState.playoff.sf2.t2 = appState.standings[2].name;

        appState.stage = 2;
        document.querySelector('[data-target="tab-bracket-stage"]').click();
        renderBracketUI();
        saveLocalState();
    });

    function renderBracketUI() {
        document.getElementById("sf1-t1-name").textContent = appState.playoff.sf1.t1 || "Tým 1";
        document.getElementById("sf1-t2-name").textContent = appState.playoff.sf1.t2 || "Tým 4";
        document.getElementById("sf1-t1-score").value = appState.playoff.sf1.s1 !== null ? appState.playoff.sf1.s1 : "";
        document.getElementById("sf1-t2-score").value = appState.playoff.sf1.s2 !== null ? appState.playoff.sf1.s2 : "";

        document.getElementById("sf2-t1-name").textContent = appState.playoff.sf2.t1 || "Tým 2";
        document.getElementById("sf2-t2-name").textContent = appState.playoff.sf2.t2 || "Tým 3";
        document.getElementById("sf2-t1-score").value = appState.playoff.sf2.s1 !== null ? appState.playoff.sf2.s1 : "";
        document.getElementById("sf2-t2-score").value = appState.playoff.sf2.s2 !== null ? appState.playoff.sf2.s2 : "";

        document.getElementById("f-t1-name").textContent = appState.playoff.final.t1 || "Čeká se na SF1";
        document.getElementById("f-t2-name").textContent = appState.playoff.final.t2 || "Čeká se na SF2";
        document.getElementById("f-t1-score").value = appState.playoff.final.s1 !== null ? appState.playoff.final.s1 : "";
        document.getElementById("f-t2-score").value = appState.playoff.final.s2 !== null ? appState.playoff.final.s2 : "";

        document.getElementById("final-row-1").classList.remove("winner-highlight");
        document.getElementById("final-row-2").classList.remove("winner-highlight");

        if(appState.playoff.final.winner) {
            if (appState.playoff.final.winner === appState.playoff.final.t1) {
                document.getElementById("final-row-1").classList.add("winner-highlight");
            } else {
                document.getElementById("final-row-2").classList.add("winner-highlight");
            }
            
            document.getElementById("btnSaveWholeBracket").disabled = false;
        } else {
            document.getElementById("btnSaveWholeBracket").disabled = true;
        }
    }

    document.getElementById("btnResolveSF1").addEventListener("click", () => {
        const s1 = parseInt(document.getElementById("sf1-t1-score").value);
        const s2 = parseInt(document.getElementById("sf1-t2-score").value);
        
        if(isNaN(s1) || isNaN(s2)) return alert("Zadejte validní skóre pro SF1.");
        if(s1 === s2) return alert("V play-off musí být určen vítěz (zadejte prodloužení/penalty).");

        appState.playoff.sf1.s1 = s1;
        appState.playoff.sf1.s2 = s2;
        appState.playoff.sf1.winner = s1 > s2 ? appState.playoff.sf1.t1 : appState.playoff.sf1.t2;
        appState.playoff.final.t1 = appState.playoff.sf1.winner;

        renderBracketUI();
        saveLocalState();
    });

    document.getElementById("btnResolveSF2").addEventListener("click", () => {
        const s1 = parseInt(document.getElementById("sf2-t1-score").value);
        const s2 = parseInt(document.getElementById("sf2-t2-score").value);
        
        if(isNaN(s1) || isNaN(s2)) return alert("Zadejte validní skóre pro SF2.");
        if(s1 === s2) return alert("V play-off musí být určen vítěz.");

        appState.playoff.sf2.s1 = s1;
        appState.playoff.sf2.s2 = s2;
        appState.playoff.sf2.winner = s1 > s2 ? appState.playoff.sf2.t1 : appState.playoff.sf2.t2;
        appState.playoff.final.t2 = appState.playoff.sf2.winner;

        renderBracketUI();
        saveLocalState();
    });

    document.getElementById("btnResolveFinal").addEventListener("click", () => {
        const s1 = parseInt(document.getElementById("f-t1-score").value);
        const s2 = parseInt(document.getElementById("f-t2-score").value);
        
        if(isNaN(s1) || isNaN(s2)) return alert("Zadejte validní skóre pro Finále.");
        if(s1 === s2) return alert("Ve finále musí být určen absolutní vítěz.");

        appState.playoff.final.s1 = s1;
        appState.playoff.final.s2 = s2;
        appState.playoff.final.winner = s1 > s2 ? appState.playoff.final.t1 : appState.playoff.final.t2;
        appState.stage = 3;

        renderBracketUI();
        saveLocalState();
    });

    document.getElementById("btnSaveWholeBracket").addEventListener("click", () => {
        const dbPayload = [
            { stage: "Semifinále 1", team1: appState.playoff.sf1.t1, team2: appState.playoff.sf1.t2, score1: appState.playoff.sf1.s1, score2: appState.playoff.sf1.s2 },
            { stage: "Semifinále 2", team1: appState.playoff.sf2.t1, team2: appState.playoff.sf2.t2, score1: appState.playoff.sf2.s1, score2: appState.playoff.sf2.s2 },
            { stage: "Finále", team1: appState.playoff.final.t1, team2: appState.playoff.final.t2, score1: appState.playoff.final.s1, score2: appState.playoff.final.s2 }
        ];

        fetch("api.php?action=save_matches", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dbPayload)
        })
        .then(res => res.json())
        .then(res => {
            if(res.status === "success") {
                alert("Výsledky play-off byly trvale zapsány do MySQL!");
                loadDatabaseHistory();
                document.querySelector('[data-target="tab-history-stage"]').click();
            } else {
                alert("Chyba při ukládání: " + res.message);
            }
        });
    });

    function loadDatabaseHistory() {
        fetch("api.php?action=get_history")
        .then(res => res.json())
        .then(res => {
            const tbody = document.getElementById("databaseHistoryTableBody");
            tbody.innerHTML = "";

            if(res.status === "success") {
                if(res.data.length === 0) {
                    tbody.innerHTML = `<tr><td colspan='6' class='text-center text-muted'>V databázi nejsou žádné historické zápasy.</td></tr>`;
                    return;
                }
                res.data.forEach(row => {
                    const tr = document.createElement("tr");
                    tr.innerHTML = `
                        <td><small>${row.datum}</small></td>
                        <td><span class="table-points-badge">${row.stage}</span></td>
                        <td class="text-right"><strong>${row.team1}</strong></td>
                        <td class="text-center" style="font-weight:800; color:var(--accent-yellow); font-size:16px;">${row.score1} : ${row.score2}</td>
                        <td class="text-left"><strong>${row.team2}</strong></td>
                        <td><span style="color:var(--accent-green)">✔ Uloženo</span></td>
                    `;
                    tbody.appendChild(tr);
                });
            } else {
                tbody.innerHTML = `<tr><td colspan='6' class='text-center text-danger'>Chyba stahování: ${res.message}</td></tr>`;
            }
        });
    }

    document.getElementById("btnRefreshHistory").addEventListener("click", loadDatabaseHistory);

    document.getElementById("btnWipeDatabaseHistory").addEventListener("click", () => {
        if(confirm("Opravdu si přejete permanentně smazat veškerou historii zápasů z MySQL databáze? Tuto akci nelze vrátit.")) {
            fetch("api.php?action=hard_reset")
            .then(res => res.json())
            .then(res => {
                alert(res.message);
                loadDatabaseHistory();
            });
        }
    });

    document.getElementById("btnTournamentReset").addEventListener("click", () => {
        if(confirm("Chcete resetovat aktuální turnaj a vymazat registrované týmy? Historie odehraných zápasů v DB zůstane.")) {
            fetch("api.php?action=reset_tournament")
            .then(res => res.json())
            .then(res => {
                alert(res.message);
                localStorage.removeItem("tournament_local_state");
                appState = {
                    teams: [],
                    groupMatches: [],
                    standings: [],
                    playoff: {
                        sf1: { t1: "", t2: "", s1: null, s2: null, winner: "" },
                        sf2: { t1: "", t2: "", s1: null, s2: null, winner: "" },
                        final: { t1: "", t2: "", s1: null, s2: null, winner: "" }
                    },
                    stage: 0
                };
                renderTeamsUI();
                renderGroupMatchesUI();
                calculateGroupTable();
                renderBracketUI();
                document.querySelector('[data-target="tab-dashboard"]').click();
            });
        }
    });

    function saveLocalState() {
        localStorage.setItem("tournament_local_state", JSON.stringify(appState));
    }

    function restoreLocalState() {
        const local = localStorage.getItem("tournament_local_state");
        if(local) {
            appState = JSON.parse(local);
            renderTeamsUI();
            renderGroupMatchesUI();
            calculateGroupTable();
            renderBracketUI();
        } else {
            renderTeamsUI();
        }
    }
});