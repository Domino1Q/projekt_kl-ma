<?php
require_once 'db.php';

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS teams (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS matches (
        id INT AUTO_INCREMENT PRIMARY KEY,
        stage VARCHAR(50) NOT NULL, 
        team1 VARCHAR(100) NOT NULL,
        team2 VARCHAR(100) NOT NULL,
        score1 INT DEFAULT NULL,
        score2 INT DEFAULT NULL,
        status VARCHAR(20) DEFAULT 'Naplánováno', 
        played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS tournament_settings (
        meta_key VARCHAR(50) PRIMARY KEY,
        meta_value TEXT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;");

    header('Content-Type: application/json');
    echo json_encode(["status" => "success", "message" => "Databáze a tabulky byly úspěšně inicializovány!"]);
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(["status" => "error", "message" => "Inicializace selhala: " . $e->getMessage()]);
}
?>